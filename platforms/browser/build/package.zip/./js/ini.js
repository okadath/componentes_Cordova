ons.platform.select('android');
ons.bootstrap();